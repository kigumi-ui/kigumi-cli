import {
  Component,
  CUSTOM_ELEMENTS_SCHEMA,
  ElementRef,
  ViewChild,
  AfterViewInit,
  inject,
  Input,
  Output,
  EventEmitter,
  OnDestroy,
} from '@angular/core';
import type WaElement from '@awesome.me/webawesome/dist/components/intersection-observer/intersection-observer.js';

let loadPromise: Promise<unknown> | null = null;
function ensureLoaded() {
  return (loadPromise ??=
    import('@awesome.me/webawesome/dist/components/intersection-observer/intersection-observer.js'));
}

/**
 * Observes changes in the intersection of a target element with an ancestor
 *
 * @see https://webawesome.com/docs/components/intersection-observer
 */
@Component({
  selector: 'k-intersection-observer',
  standalone: true,
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  template: `
    <wa-intersection-observer
      #element
      [attr.disabled]="disabled || null"
      [attr.once]="once || null"
      [attr.threshold]="threshold"
      [attr.root-margin]="rootMargin"
      [attr.intersect-class]="intersectClass"
    >
      <ng-content />
    </wa-intersection-observer>
  `,
  styleUrl: './intersection-observer.component.css',
})
export class IntersectionObserverComponent implements AfterViewInit, OnDestroy {
  @ViewChild('element') elementRef!: ElementRef<WaElement>;
  private hostRef = inject(ElementRef<HTMLElement>);

  /** Disables the observer */
  @Input() disabled?: boolean;
  /** Stops observing after first intersection */
  @Input() once?: boolean;
  /** Intersection thresholds */
  @Input() threshold?: string;
  /** Root element margin */
  @Input() rootMargin?: string;
  /** CSS class to apply when intersecting */
  @Input() intersectClass?: string;

  @Output() intersect = new EventEmitter<CustomEvent>();

  private cleanups: (() => void)[] = [];

  ngAfterViewInit(): void {
    ensureLoaded();
    const el = this.elementRef.nativeElement;

    // Forward host attributes to inner wa-* element
    const host = this.hostRef.nativeElement;
    const hostStyle = host.getAttribute('style');
    if (hostStyle) {
      el.setAttribute('style', hostStyle);
      host.removeAttribute('style');
    }
    // When slotted, override display:contents so ::slotted() margins apply
    if (host.hasAttribute('slot')) {
      host.style.display = 'inline';
    }

    const handleIntersect = (e: Event) => this.intersect.emit(e as CustomEvent);
    el.addEventListener('wa-intersect', handleIntersect);
    this.cleanups.push(() =>
      el.removeEventListener('wa-intersect', handleIntersect)
    );
  }

  ngOnDestroy(): void {
    this.cleanups.forEach((fn) => fn());
  }
}
