import {
  Component,
  CUSTOM_ELEMENTS_SCHEMA,
  ElementRef,
  ViewChild,
  AfterViewInit,
  inject,
  Input,
} from '@angular/core';
import type WaElement from '@awesome.me/webawesome/dist/components/polar-area-chart/polar-area-chart.js';

let loadPromise: Promise<unknown> | null = null;
function ensureLoaded() {
  return (loadPromise ??=
    import('@awesome.me/webawesome/dist/components/polar-area-chart/polar-area-chart.js'));
}

/**
 * Arranges segments of equal angle but varying radius around a central point
 *
 * @see https://webawesome.com/docs/components/polar-area-chart
 */
@Component({
  selector: 'k-polar-area-chart',
  standalone: true,
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  template: `
    <wa-polar-area-chart
      #element
      [attr.label]="label"
      [attr.description]="description"
      [attr.legend-position]="legendPosition"
      [attr.without-animation]="withoutAnimation || null"
      [attr.without-legend]="withoutLegend || null"
      [attr.without-tooltip]="withoutTooltip || null"
    >
      <ng-content />
    </wa-polar-area-chart>
  `,
  styleUrl: './polar-area-chart.component.css',
})
export class PolarAreaChartComponent implements AfterViewInit {
  @ViewChild('element') elementRef!: ElementRef<WaElement>;
  private hostRef = inject(ElementRef<HTMLElement>);

  /** Accessible name announced by assistive technology */
  @Input() label?: string;
  /** Extended accessible description for the chart */
  @Input() description?: string;
  /** Placement of the dataset legend relative to the chart */
  @Input() legendPosition?:
    | 'top'
    | 'right'
    | 'bottom'
    | 'left'
    | 'start'
    | 'end';
  /** Disables entrance and update motion effects */
  @Input() withoutAnimation?: boolean;
  /** Hides the dataset legend entirely */
  @Input() withoutLegend?: boolean;
  /** Prevents hover tooltips from appearing on data points */
  @Input() withoutTooltip?: boolean;

  ngAfterViewInit(): void {
    ensureLoaded();
    const el = this.elementRef.nativeElement;

    // Forward host attributes to inner wa-* element
    const host = this.hostRef.nativeElement;
    const hostStyle = host.getAttribute('style');
    if (hostStyle) {
      el.setAttribute('style', hostStyle);
      host.removeAttribute('style');
    }
    // When slotted, override display:contents so ::slotted() margins apply
    if (host.hasAttribute('slot')) {
      host.style.display = 'inline';
    }
  }
}
