import {
  Component,
  CUSTOM_ELEMENTS_SCHEMA,
  ElementRef,
  ViewChild,
  AfterViewInit,
  inject,
  Input,
  Output,
  EventEmitter,
  OnDestroy,
} from '@angular/core';
import type WaElement from '@awesome.me/webawesome/dist/components/carousel/carousel.js';

let loadPromise: Promise<unknown> | null = null;
function ensureLoaded() {
  return (loadPromise ??=
    import('@awesome.me/webawesome/dist/components/carousel/carousel.js'));
}

/**
 * Displays an arbitrary number of content slides along a horizontal or vertical axis
 *
 * @see https://webawesome.com/docs/components/carousel
 */
@Component({
  selector: 'k-carousel',
  standalone: true,
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  template: `
    <wa-carousel
      #element
      [attr.autoplay]="autoplay || null"
      [attr.autoplay-interval]="autoplayInterval"
      [attr.loop]="loop || null"
      [attr.mouse-dragging]="mouseDragging || null"
      [attr.navigation]="navigation || null"
      [attr.orientation]="orientation"
      [attr.pagination]="pagination || null"
      [attr.slides-per-move]="slidesPerMove"
      [attr.slides-per-page]="slidesPerPage"
    >
      <ng-content />
    </wa-carousel>
  `,
  styleUrl: './carousel.component.css',
})
export class CarouselComponent implements AfterViewInit, OnDestroy {
  @ViewChild('element') elementRef!: ElementRef<WaElement>;
  private hostRef = inject(ElementRef<HTMLElement>);

  /** Automatically scrolls slides when user isn't interacting */
  @Input() autoplay?: boolean;
  /** Milliseconds between automatic scrolls */
  @Input() autoplayInterval?: number;
  /** Allows infinite navigation in same direction */
  @Input() loop?: boolean;
  /** Enables dragging slides with mouse */
  @Input() mouseDragging?: boolean;
  /** Shows previous/next buttons */
  @Input() navigation?: boolean;
  /** Carousel layout direction */
  @Input() orientation?: 'horizontal' | 'vertical';
  /** Shows slide indicator dots */
  @Input() pagination?: boolean;
  /** Number of slides to advance per scroll */
  @Input() slidesPerMove?: number;
  /** Number of slides visible at once */
  @Input() slidesPerPage?: number;

  @Output() slideChange = new EventEmitter<CustomEvent>();

  private cleanups: (() => void)[] = [];

  ngAfterViewInit(): void {
    ensureLoaded();
    const el = this.elementRef.nativeElement;

    // Forward host attributes to inner wa-* element
    const host = this.hostRef.nativeElement;
    const hostStyle = host.getAttribute('style');
    if (hostStyle) {
      el.setAttribute('style', hostStyle);
      host.removeAttribute('style');
    }
    // When slotted, override display:contents so ::slotted() margins apply
    if (host.hasAttribute('slot')) {
      host.style.display = 'inline';
    }

    const handleSlideChange = (e: Event) =>
      this.slideChange.emit(e as CustomEvent);
    el.addEventListener('wa-slide-change', handleSlideChange);
    this.cleanups.push(() =>
      el.removeEventListener('wa-slide-change', handleSlideChange)
    );
  }

  ngOnDestroy(): void {
    this.cleanups.forEach((fn) => fn());
  }

  previous(behavior?: ScrollBehavior): void {
    (
      this.elementRef.nativeElement as unknown as {
        previous: (behavior?: ScrollBehavior) => void;
      }
    ).previous(behavior);
  }
  next(behavior?: ScrollBehavior): void {
    (
      this.elementRef.nativeElement as unknown as {
        next: (behavior?: ScrollBehavior) => void;
      }
    ).next(behavior);
  }
  goToSlide(index?: number, behavior?: ScrollBehavior): void {
    (
      this.elementRef.nativeElement as unknown as {
        goToSlide: (index?: number, behavior?: ScrollBehavior) => void;
      }
    ).goToSlide(index, behavior);
  }
}
