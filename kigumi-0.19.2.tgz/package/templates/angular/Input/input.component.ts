import {
  Component,
  CUSTOM_ELEMENTS_SCHEMA,
  ElementRef,
  ViewChild,
  AfterViewInit,
  inject,
  Input,
  Output,
  EventEmitter,
  OnDestroy,
  forwardRef,
} from '@angular/core';
import { NG_VALUE_ACCESSOR, type ControlValueAccessor } from '@angular/forms';
import type WaElement from '@awesome.me/webawesome/dist/components/input/input.js';

let loadPromise: Promise<unknown> | null = null;
function ensureLoaded() {
  return (loadPromise ??=
    import('@awesome.me/webawesome/dist/components/input/input.js'));
}

/**
 * Inputs collect data from the user
 *
 * @see https://webawesome.com/docs/components/input
 */
@Component({
  selector: 'k-input',
  standalone: true,
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  template: `
    <wa-input
      #element
      [attr.type]="type"
      [attr.label]="label"
      [attr.hint]="hint"
      [attr.placeholder]="placeholder"
      [attr.value]="value"
      [attr.appearance]="appearance"
      [attr.size]="size"
      [attr.pill]="pill || null"
      [attr.disabled]="disabled || null"
      [attr.with-clear]="withClear || null"
      [attr.password-toggle]="passwordToggle || null"
      [attr.password-visible]="passwordVisible || null"
      [attr.readonly]="readonly || null"
      [attr.required]="required || null"
      [attr.name]="name"
      [attr.pattern]="pattern"
      [attr.minlength]="minlength"
      [attr.maxlength]="maxlength"
      [attr.min]="min"
      [attr.max]="max"
      [attr.step]="step"
      [attr.without-spin-buttons]="withoutSpinButtons || null"
      [attr.autocomplete]="autocomplete"
      [attr.autocapitalize]="autocapitalize"
      [attr.autocorrect]="autocorrect || null"
      [attr.autofocus]="autofocus || null"
      [attr.inputmode]="inputmode"
      [attr.enterkeyhint]="enterkeyhint"
    >
      <ng-content />
    </wa-input>
  `,
  styleUrl: './input.component.css',
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => InputComponent),
      multi: true,
    },
  ],
})
export class InputComponent
  implements AfterViewInit, OnDestroy, ControlValueAccessor
{
  @ViewChild('element') elementRef!: ElementRef<WaElement>;
  private hostRef = inject(ElementRef<HTMLElement>);

  /** Input type */
  @Input() type?:
    | 'text'
    | 'email'
    | 'password'
    | 'number'
    | 'date'
    | 'tel'
    | 'url'
    | 'search';
  /** Accessible label for the input */
  @Input() label?: string;
  /** Descriptive hint text */
  @Input() hint?: string;
  /** Placeholder text */
  @Input() placeholder?: string;
  /** Input value */
  @Input() value?: string;
  /** Visual appearance style */
  @Input() appearance?: 'filled' | 'filled-outlined' | 'outlined';
  /** Input size */
  @Input() size?: 'small' | 'medium' | 'large';
  /** Gives the input rounded edges */
  @Input() pill?: boolean;
  /** Disables the input */
  @Input() disabled?: boolean;
  /** Adds a clear button when input has content */
  @Input() withClear?: boolean;
  /** Adds a toggle button for password visibility */
  @Input() passwordToggle?: boolean;
  /** Shows the password as plain text when set */
  @Input() passwordVisible?: boolean;
  /** Makes the input readonly */
  @Input() readonly?: boolean;
  /** Makes the input required */
  @Input() required?: boolean;
  /** The name of the input for form submission */
  @Input() name?: string;
  /** A regular expression pattern the value must match */
  @Input() pattern?: string;
  /** Minimum string length */
  @Input() minlength?: number;
  /** Maximum string length */
  @Input() maxlength?: number;
  /** Minimum value for numeric and date types */
  @Input() min?: string;
  /** Maximum value for numeric and date types */
  @Input() max?: string;
  /** Step increment for numeric types */
  @Input() step?: string;
  /** Hides the browser's built-in spin buttons */
  @Input() withoutSpinButtons?: boolean;
  /** Hint for autocomplete behavior */
  @Input() autocomplete?: string;
  /** Controls automatic capitalization */
  @Input() autocapitalize?:
    | 'off'
    | 'none'
    | 'on'
    | 'sentences'
    | 'words'
    | 'characters';
  /** Enable autocorrect */
  @Input() autocorrect?: boolean;
  /** Automatically focuses the input on page load */
  @Input() autofocus?: boolean;
  /** Hint for virtual keyboard type */
  @Input() inputmode?:
    | 'none'
    | 'text'
    | 'decimal'
    | 'numeric'
    | 'tel'
    | 'search'
    | 'email'
    | 'url';
  /** Hint for Enter key label on virtual keyboards */
  @Input() enterkeyhint?:
    | 'enter'
    | 'done'
    | 'go'
    | 'next'
    | 'previous'
    | 'search'
    | 'send';

  @Output() inputEvent = new EventEmitter<CustomEvent>();
  @Output() change = new EventEmitter<CustomEvent>();
  @Output() blurEvent = new EventEmitter<CustomEvent>();
  @Output() focusEvent = new EventEmitter<FocusEvent>();
  @Output() clear = new EventEmitter<CustomEvent>();
  @Output() invalid = new EventEmitter<CustomEvent>();

  private onChangeCallback: (value: unknown) => void = () => {};
  private onTouchedCallback: () => void = () => {};

  private cleanups: (() => void)[] = [];

  ngAfterViewInit(): void {
    ensureLoaded();
    const el = this.elementRef.nativeElement;

    // Forward host attributes to inner wa-* element
    const host = this.hostRef.nativeElement;
    const hostStyle = host.getAttribute('style');
    if (hostStyle) {
      el.setAttribute('style', hostStyle);
      host.removeAttribute('style');
    }
    // When slotted, override display:contents so ::slotted() margins apply
    if (host.hasAttribute('slot')) {
      host.style.display = 'inline';
    }

    const handleInputEvent = (e: Event) =>
      this.inputEvent.emit(e as CustomEvent);
    el.addEventListener('input', handleInputEvent);
    this.cleanups.push(() => el.removeEventListener('input', handleInputEvent));
    const handleChange = (e: Event) => this.change.emit(e as CustomEvent);
    el.addEventListener('change', handleChange);
    this.cleanups.push(() => el.removeEventListener('change', handleChange));
    const handleBlurEvent = (e: Event) => this.blurEvent.emit(e as CustomEvent);
    el.addEventListener('blur', handleBlurEvent);
    this.cleanups.push(() => el.removeEventListener('blur', handleBlurEvent));
    const handleFocusEvent = (e: Event) =>
      this.focusEvent.emit(e as FocusEvent);
    el.addEventListener('focus', handleFocusEvent);
    this.cleanups.push(() => el.removeEventListener('focus', handleFocusEvent));
    const handleClear = (e: Event) => this.clear.emit(e as CustomEvent);
    el.addEventListener('wa-clear', handleClear);
    this.cleanups.push(() => el.removeEventListener('wa-clear', handleClear));
    const handleInvalid = (e: Event) => this.invalid.emit(e as CustomEvent);
    el.addEventListener('wa-invalid', handleInvalid);
    this.cleanups.push(() =>
      el.removeEventListener('wa-invalid', handleInvalid)
    );

    const handleValueChange = () =>
      this.onChangeCallback((el as unknown as { value: unknown }).value);
    el.addEventListener('input', handleValueChange);
    this.cleanups.push(() =>
      el.removeEventListener('input', handleValueChange)
    );
    const handleBlurTouch = () => this.onTouchedCallback();
    el.addEventListener('blur', handleBlurTouch);
    this.cleanups.push(() => el.removeEventListener('blur', handleBlurTouch));
  }

  ngOnDestroy(): void {
    this.cleanups.forEach((fn) => fn());
  }

  writeValue(value: unknown): void {
    if (this.elementRef?.nativeElement) {
      (this.elementRef.nativeElement as unknown as { value: unknown }).value =
        value ?? '';
    }
  }

  registerOnChange(fn: (value: unknown) => void): void {
    this.onChangeCallback = fn;
  }

  registerOnTouched(fn: () => void): void {
    this.onTouchedCallback = fn;
  }

  setDisabledState(isDisabled: boolean): void {
    if (this.elementRef?.nativeElement) {
      (
        this.elementRef.nativeElement as unknown as { disabled: boolean }
      ).disabled = isDisabled;
    }
  }

  focus(options?: FocusOptions): void {
    (
      this.elementRef.nativeElement as unknown as {
        focus: (options?: FocusOptions) => void;
      }
    ).focus(options);
  }
  blur(): void {
    (this.elementRef.nativeElement as unknown as { blur: () => void }).blur();
  }
  select(): void {
    (
      this.elementRef.nativeElement as unknown as { select: () => void }
    ).select();
  }
  setSelectionRange(
    selectionStart?: number,
    selectionEnd?: number,
    selectionDirection?: 'forward' | 'backward' | 'none'
  ): void {
    (
      this.elementRef.nativeElement as unknown as {
        setSelectionRange: (
          selectionStart?: number,
          selectionEnd?: number,
          selectionDirection?: 'forward' | 'backward' | 'none'
        ) => void;
      }
    ).setSelectionRange(selectionStart, selectionEnd, selectionDirection);
  }
  setRangeText(
    replacement?: string,
    start?: number,
    end?: number,
    selectMode?: 'select' | 'start' | 'end' | 'preserve'
  ): void {
    (
      this.elementRef.nativeElement as unknown as {
        setRangeText: (
          replacement?: string,
          start?: number,
          end?: number,
          selectMode?: 'select' | 'start' | 'end' | 'preserve'
        ) => void;
      }
    ).setRangeText(replacement, start, end, selectMode);
  }
  showPicker(): void {
    (
      this.elementRef.nativeElement as unknown as { showPicker: () => void }
    ).showPicker();
  }
  stepUp(): void {
    (
      this.elementRef.nativeElement as unknown as { stepUp: () => void }
    ).stepUp();
  }
  stepDown(): void {
    (
      this.elementRef.nativeElement as unknown as { stepDown: () => void }
    ).stepDown();
  }
  setCustomValidity(message?: string): void {
    (
      this.elementRef.nativeElement as unknown as {
        setCustomValidity: (message?: string) => void;
      }
    ).setCustomValidity(message);
  }
  formStateRestoreCallback(
    state?: string | File | FormData | null,
    reason?: 'autocomplete' | 'restore'
  ): void {
    (
      this.elementRef.nativeElement as unknown as {
        formStateRestoreCallback: (
          state?: string | File | FormData | null,
          reason?: 'autocomplete' | 'restore'
        ) => void;
      }
    ).formStateRestoreCallback(state, reason);
  }
  resetValidity(): void {
    (
      this.elementRef.nativeElement as unknown as { resetValidity: () => void }
    ).resetValidity();
  }
}
