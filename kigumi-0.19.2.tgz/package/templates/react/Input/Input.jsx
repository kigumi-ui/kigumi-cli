import React from 'react';
import clsx from 'clsx';
import './Input.css';

let loadPromise = null;
function ensureLoaded() {
  return (loadPromise ??=
    import('@awesome.me/webawesome/dist/components/input/input.js'));
}

/**
 * Inputs collect data from the user
 *
 * @example
 * ```jsx
 * // Basic usage
 * <Input label="Email" type="email" placeholder="Enter email" />
 * <Input type="password" password-toggle />
 * <Input with-clear hint="Help text" />
 *
 * // With event handlers
 * <Input
 *   label="Name"
 *   onInput={(e) => console.log(e.target.value)}
 *   onChange={(e) => console.log('Changed:', e.target.value)}
 * />
 *
 * // With ref methods
 * const inputRef = React.useRef(null);
 * <button onClick={() => inputRef.current?.focus()}>Focus Input</button>
 * <Input ref={inputRef} label="Focusable" />
 * ```
 *
 * @typedef {Object} InputProps
 * @property {string} [type] - Input type: text | email | password | number | date | tel | url | search
 * @property {string} [label] - Accessible label
 * @property {string} [hint] - Descriptive hint text
 * @property {string} [placeholder] - Placeholder text
 * @property {string} [value] - Input value
 * @property {string} [appearance] - Visual appearance: filled | filled-outlined | outlined
 * @property {string} [size] - Input size: small | medium | large
 * @property {boolean} [pill] - Rounded edges
 * @property {boolean} [disabled] - Disables the input
 * @property {boolean} [with-clear] - Adds clear button
 * @property {boolean} [password-toggle] - Adds password toggle
 * @property {boolean} [password-visible] - Shows password as plain text
 * @property {boolean} [readonly] - Makes the input readonly
 * @property {boolean} [required] - Makes the input required
 * @property {string} [name] - Name for form submission
 * @property {string} [pattern] - Regular expression pattern
 * @property {number} [minlength] - Minimum string length
 * @property {number} [maxlength] - Maximum string length
 * @property {string} [min] - Minimum value (numeric/date types)
 * @property {string} [max] - Maximum value (numeric/date types)
 * @property {string} [step] - Step increment
 * @property {boolean} [without-spin-buttons] - Hides spin buttons
 * @property {string} [autocomplete] - Hint for autocomplete
 * @property {string} [autocapitalize] - Capitalization hint
 * @property {boolean} [autocorrect] - Enable autocorrect
 * @property {boolean} [autofocus] - Auto-focus on page load
 * @property {string} [inputmode] - Virtual keyboard hint
 * @property {string} [enterkeyhint] - Enter key label hint
 * @property {function} [onBlur] - Event fired when input loses focus
 * @property {function} [onFocus] - Event fired when input gains focus
 * @property {function} [onInput] - Event fired when value changes
 * @property {function} [onChange] - Event fired when value is committed
 * @property {function} [onClear] - Event fired when clear button is activated
 */

export const Input = React.forwardRef(
  (
    { children, className, onBlur, onFocus, onInput, onChange, ...props },
    ref
  ) => {
    const inputRef = React.useRef(null);

    React.useImperativeHandle(
      ref,
      () => ({
        focus: () => {
          if (
            inputRef.current &&
            typeof inputRef.current.focus === 'function'
          ) {
            inputRef.current.focus();
          }
        },
        blur: () => {
          if (inputRef.current && typeof inputRef.current.blur === 'function') {
            inputRef.current.blur();
          }
        },
        select: () => {
          if (
            inputRef.current &&
            typeof inputRef.current.select === 'function'
          ) {
            inputRef.current.select();
          }
        },
        setSelectionRange: (start, end) => {
          if (
            inputRef.current &&
            typeof inputRef.current.setSelectionRange === 'function'
          ) {
            inputRef.current.setSelectionRange(start, end);
          }
        },
        get element() {
          return inputRef.current;
        },
      }),
      []
    );

    React.useEffect(() => {
      ensureLoaded();
      const el = inputRef.current;
      if (!el) return;

      const handleBlur = (e) => {
        if (onBlur) onBlur(e);
      };

      const handleFocus = (e) => {
        if (onFocus) onFocus(e);
      };

      const handleInput = (e) => {
        if (onInput) onInput(e);
      };

      const handleChange = (e) => {
        if (onChange) onChange(e);
      };

      el.addEventListener('blur', handleBlur);
      el.addEventListener('focus', handleFocus);
      el.addEventListener('input', handleInput);
      el.addEventListener('change', handleChange);

      return () => {
        el.removeEventListener('blur', handleBlur);
        el.removeEventListener('focus', handleFocus);
        el.removeEventListener('input', handleInput);
        el.removeEventListener('change', handleChange);
      };
    }, [onBlur, onFocus, onInput, onChange]);

    return (
      <wa-input ref={inputRef} class={clsx('Input', className)} {...props}>
        {children}
      </wa-input>
    );
  }
);

Input.displayName = 'Input';
