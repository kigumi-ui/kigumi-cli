import {
  forwardRef,
  useRef,
  useCallback,
  useImperativeHandle,
  useEffect,
  type HTMLAttributes,
} from 'react';
import clsx from 'clsx';
import type WaBubbleChart from '@awesome.me/webawesome/dist/components/bubble-chart/bubble-chart.js';
import './BubbleChart.css';

let loadPromise: Promise<unknown> | null = null;
function ensureLoaded() {
  return (loadPromise ??=
    import('@awesome.me/webawesome/dist/components/bubble-chart/bubble-chart.js'));
}

/**
 * Plots three-dimensional data using position and circle size to encode a third variable
 *
 * @example
 * ```tsx
 * // Basic usage
 * <BubbleChart />
 *
 * // With event handlers
 * <BubbleChart />
 *
 * ```
 */
export interface BubbleChartProps extends Omit<
  HTMLAttributes<HTMLElement>,
  'dir'
> {
  /** Accessible name announced by assistive technology */
  label?: string;

  /** Extended accessible description for the chart */
  description?: string;

  /** Caption displayed beneath the horizontal axis */
  'x-label'?: string;

  /** Caption displayed beside the vertical axis */
  'y-label'?: string;

  /** Placement of the dataset legend relative to the chart */
  'legend-position'?: 'top' | 'right' | 'bottom' | 'left' | 'start' | 'end';

  /** Layers multiple datasets on a single axis */
  stacked?: boolean;

  /** Base axis for category labels (swap to flip chart orientation) */
  'index-axis'?: 'x' | 'y';

  /** Selects which background grid lines are drawn */
  grid?: 'x' | 'y' | 'both' | 'none';

  /** Floor value for the value axis scale */
  min?: number;

  /** Ceiling value for the value axis scale */
  max?: number;

  /** Disables entrance and update motion effects */
  'without-animation'?: boolean;

  /** Hides the dataset legend entirely */
  'without-legend'?: boolean;

  /** Prevents hover tooltips from appearing on data points */
  'without-tooltip'?: boolean;
}

export interface BubbleChartRef {
  /** Reference to the underlying HTML element */
  element: WaBubbleChart | null;
}

export const BubbleChart = forwardRef<BubbleChartRef, BubbleChartProps>(
  ({ children, className, ...props }, ref) => {
    const bubblechartRef = useRef<WaBubbleChart | null>(null);
    const setBubbleChartRef = useCallback((el: WaBubbleChart | null) => {
      bubblechartRef.current = el;
    }, []);

    useImperativeHandle(
      ref,
      () => ({
        get element() {
          return bubblechartRef.current;
        },
      }),
      []
    );

    useEffect(() => {
      ensureLoaded();
    }, []);

    return (
      <wa-bubble-chart
        ref={setBubbleChartRef}
        class={clsx('BubbleChart', className)}
        {...({ suppressHydrationWarning: true, ...props } as Record<
          string,
          unknown
        >)}
      >
        {children}
      </wa-bubble-chart>
    );
  }
);

BubbleChart.displayName = 'BubbleChart';
