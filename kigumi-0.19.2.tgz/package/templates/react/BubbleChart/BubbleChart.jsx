import React from 'react';
import clsx from 'clsx';
import './BubbleChart.css';

let loadPromise = null;
function ensureLoaded() {
  return (loadPromise ??=
    import('@awesome.me/webawesome/dist/components/bubble-chart/bubble-chart.js'));
}

/**
 * Plots three-dimensional data using position and circle size to encode a third variable
 *
 * @example
 * ```jsx
 * <BubbleChart label="Population vs GDP">
 *   <script type="application/json">{JSON.stringify({
 *     data: {
 *       datasets: [{ label: 'Countries', data: [{ x: 20, y: 30, r: 15 }, { x: 40, y: 10, r: 10 }] }]
 *     }
 *   })}</script>
 * </BubbleChart>
 * ```
 *
 * @typedef {Object} BubbleChartProps
 * @property {string} [label] - Accessible name announced by assistive technology
 * @property {string} [description] - Extended accessible description for the chart
 * @property {string} [x-label] - Caption displayed beneath the horizontal axis
 * @property {string} [y-label] - Caption displayed beside the vertical axis
 * @property {string} [legend-position] - Placement of the legend: top | right | bottom | left | start | end
 * @property {boolean} [stacked] - Layers multiple datasets on a single axis
 * @property {string} [index-axis] - Base axis for category labels: x | y
 * @property {string} [grid] - Background grid lines: x | y | both | none
 * @property {number} [min] - Floor value for the value axis scale
 * @property {number} [max] - Ceiling value for the value axis scale
 * @property {boolean} [without-animation] - Disables entrance and update motion effects
 * @property {boolean} [without-legend] - Hides the dataset legend entirely
 * @property {boolean} [without-tooltip] - Prevents hover tooltips from appearing on data points
 */

export const BubbleChart = React.forwardRef(
  ({ children, className, ...props }, ref) => {
    const bubbleChartRef = React.useRef(null);

    React.useImperativeHandle(
      ref,
      () => ({
        get element() {
          return bubbleChartRef.current;
        },
      }),
      []
    );

    React.useEffect(() => {
      ensureLoaded();
    }, []);

    return (
      <wa-bubble-chart
        ref={bubbleChartRef}
        class={clsx('BubbleChart', className)}
        {...props}
      >
        {children}
      </wa-bubble-chart>
    );
  }
);

BubbleChart.displayName = 'BubbleChart';
