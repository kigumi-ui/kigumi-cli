import React from 'react';
import clsx from 'clsx';
import './NumberInput.css';

let loadPromise = null;
function ensureLoaded() {
  return (loadPromise ??=
    import('@awesome.me/webawesome/dist/components/number-input/number-input.js'));
}

/**
 * Number inputs allow users to enter numeric values with optional step controls
 *
 * @example
 * ```jsx
 * // Basic usage
 * <NumberInput label="Quantity" min={0} max={100} />
 * <NumberInput step={0.1} value={5.5} />
 * <NumberInput without-steppers />
 *
 * // With event handlers
 * <NumberInput
 *   label="Amount"
 *   onInput={(e) => console.log('Value changed')}
 *   onChange={(e) => console.log('Value committed')}
 * />
 *
 * // With ref methods
 * const numberInputRef = React.useRef(null);
 * <button onClick={() => numberInputRef.current?.focus()}>Focus</button>
 * <NumberInput ref={numberInputRef} label="Number" />
 * ```
 *
 * @typedef {Object} NumberInputProps
 * @property {string} [label] - Accessible label
 * @property {string} [hint] - Descriptive hint text
 * @property {number} [value] - Current value
 * @property {number} [min] - Minimum value
 * @property {number} [max] - Maximum value
 * @property {number} [step] - Step increment
 * @property {string} [placeholder] - Placeholder text
 * @property {string} [appearance] - Visual appearance: filled | outlined | filled-outlined
 * @property {string} [size] - Input size: small | medium | large
 * @property {boolean} [disabled] - Disables the input
 * @property {boolean} [required] - Makes field mandatory
 * @property {boolean} [without-steppers] - Hides the stepper buttons
 * @property {function} [onBlur] - Event fired when input loses focus
 * @property {function} [onFocus] - Event fired when input gains focus
 * @property {function} [onInput] - Event fired when value changes
 * @property {function} [onChange] - Event fired when value is committed
 */

export const NumberInput = React.forwardRef(
  (
    { children, className, onBlur, onFocus, onInput, onChange, ...props },
    ref
  ) => {
    const numberInputRef = React.useRef(null);

    React.useImperativeHandle(
      ref,
      () => ({
        focus: () => {
          if (
            numberInputRef.current &&
            typeof numberInputRef.current.focus === 'function'
          ) {
            numberInputRef.current.focus();
          }
        },
        blur: () => {
          if (
            numberInputRef.current &&
            typeof numberInputRef.current.blur === 'function'
          ) {
            numberInputRef.current.blur();
          }
        },
        select: () => {
          if (
            numberInputRef.current &&
            typeof numberInputRef.current.select === 'function'
          ) {
            numberInputRef.current.select();
          }
        },
        setSelectionRange: (start, end) => {
          if (
            numberInputRef.current &&
            typeof numberInputRef.current.setSelectionRange === 'function'
          ) {
            numberInputRef.current.setSelectionRange(start, end);
          }
        },
        get element() {
          return numberInputRef.current;
        },
      }),
      []
    );

    React.useEffect(() => {
      ensureLoaded();
      const el = numberInputRef.current;
      if (!el) return;

      const handleBlur = (e) => {
        if (onBlur) onBlur(e);
      };

      const handleFocus = (e) => {
        if (onFocus) onFocus(e);
      };

      const handleInput = (e) => {
        if (onInput) onInput(e);
      };

      const handleChange = (e) => {
        if (onChange) onChange(e);
      };

      el.addEventListener('blur', handleBlur);
      el.addEventListener('focus', handleFocus);
      el.addEventListener('input', handleInput);
      el.addEventListener('change', handleChange);

      return () => {
        el.removeEventListener('blur', handleBlur);
        el.removeEventListener('focus', handleFocus);
        el.removeEventListener('input', handleInput);
        el.removeEventListener('change', handleChange);
      };
    }, [onBlur, onFocus, onInput, onChange]);

    return (
      <wa-number-input
        ref={numberInputRef}
        class={clsx('NumberInput', className)}
        {...props}
      >
        {children}
      </wa-number-input>
    );
  }
);

NumberInput.displayName = 'NumberInput';
