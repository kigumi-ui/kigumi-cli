import React from 'react';
import { createPortal } from 'react-dom';
import clsx from 'clsx';
import './Toast.css';

let loadPromise = null;
function ensureLoaded() {
  return (loadPromise ??=
    import('@awesome.me/webawesome/dist/components/toast/toast.js'));
}

/**
 * Container that manages and stacks lightweight notification banners at a chosen screen edge
 *
 * @example
 * ```jsx
 * // Declarative usage with ToastItem children
 * <Toast placement="top-end">
 *   <ToastItem variant="success">File saved!</ToastItem>
 * </Toast>
 *
 * // Programmatic usage with ref
 * const toastRef = React.useRef(null);
 * toastRef.current?.create('Hello!', { variant: 'brand' });
 * <Toast ref={toastRef} />
 * ```
 *
 * @typedef {Object} ToastProps
 * @property {string} [placement] - Screen corner or edge where notifications are anchored: top-start | top-center | top-end | bottom-start | bottom-center | bottom-end
 */

export const Toast = React.forwardRef(
  ({ children, className, ...props }, ref) => {
    const toastRef = React.useRef(null);

    React.useImperativeHandle(
      ref,
      () => ({
        create: (message, options) => {
          toastRef.current?.create?.(message, options);
        },
        get element() {
          return toastRef.current;
        },
      }),
      []
    );

    React.useEffect(() => {
      ensureLoaded();
    }, []);

    return createPortal(
      <wa-toast ref={toastRef} class={clsx('Toast', className)} {...props}>
        {children}
      </wa-toast>,
      document.body
    );
  }
);

Toast.displayName = 'Toast';
