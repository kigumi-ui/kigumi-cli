import React from 'react';
import clsx from 'clsx';
import './FileInput.css';

let loadPromise = null;
function ensureLoaded() {
  return (loadPromise ??=
    import('@awesome.me/webawesome/dist/components/file-input/file-input.js'));
}

/**
 * File inputs allow users to select and upload files from their device
 *
 * @example
 * ```jsx
 * // Basic usage
 * <FileInput label="Upload document" accept=".pdf,.doc" />
 * <FileInput multiple />
 * <FileInput hint="Select up to 5 files" required />
 *
 * // With event handlers
 * <FileInput
 *   label="Upload files"
 *   onChange={(e) => console.log('Files changed')}
 * />
 *
 * // With ref methods
 * const fileInputRef = React.useRef(null);
 * <button onClick={() => fileInputRef.current?.focus()}>Focus</button>
 * <FileInput ref={fileInputRef} label="Upload" />
 * ```
 *
 * @typedef {Object} FileInputProps
 * @property {string} [label] - Accessible label
 * @property {string} [hint] - Descriptive hint text
 * @property {string} [accept] - Accepted file types (MIME types or extensions)
 * @property {boolean} [multiple] - Allow multiple file selection
 * @property {string} [size] - Input size: small | medium | large
 * @property {boolean} [disabled] - Disables the input
 * @property {boolean} [required] - Makes field mandatory
 * @property {function} [onBlur] - Event fired when input loses focus
 * @property {function} [onFocus] - Event fired when input gains focus
 * @property {function} [onInput] - Event fired when file selection changes
 * @property {function} [onChange] - Event fired when files are added or removed
 */

export const FileInput = React.forwardRef(
  (
    { children, className, onBlur, onFocus, onInput, onChange, ...props },
    ref
  ) => {
    const fileInputRef = React.useRef(null);

    React.useImperativeHandle(
      ref,
      () => ({
        focus: () => {
          if (
            fileInputRef.current &&
            typeof fileInputRef.current.focus === 'function'
          ) {
            fileInputRef.current.focus();
          }
        },
        blur: () => {
          if (
            fileInputRef.current &&
            typeof fileInputRef.current.blur === 'function'
          ) {
            fileInputRef.current.blur();
          }
        },
        get element() {
          return fileInputRef.current;
        },
      }),
      []
    );

    React.useEffect(() => {
      ensureLoaded();
      const el = fileInputRef.current;
      if (!el) return;

      const handleBlur = (e) => {
        if (onBlur) onBlur(e);
      };

      const handleFocus = (e) => {
        if (onFocus) onFocus(e);
      };

      const handleInput = (e) => {
        if (onInput) onInput(e);
      };

      const handleChange = (e) => {
        if (onChange) onChange(e);
      };

      el.addEventListener('blur', handleBlur);
      el.addEventListener('focus', handleFocus);
      el.addEventListener('input', handleInput);
      el.addEventListener('change', handleChange);

      return () => {
        el.removeEventListener('blur', handleBlur);
        el.removeEventListener('focus', handleFocus);
        el.removeEventListener('input', handleInput);
        el.removeEventListener('change', handleChange);
      };
    }, [onBlur, onFocus, onInput, onChange]);

    return (
      <wa-file-input
        ref={fileInputRef}
        class={clsx('FileInput', className)}
        {...props}
      >
        {children}
      </wa-file-input>
    );
  }
);

FileInput.displayName = 'FileInput';
