import React from 'react';
import { render } from '@testing-library/react';
import { Sparkline } from './Sparkline';

describe('Sparkline', () => {
  it('renders without crashing', () => {
    const { container } = render(<Sparkline data="1,2,3" />);
    expect(container.querySelector('wa-sparkline')).toBeInTheDocument();
  });

  it('applies custom className', () => {
    const { container } = render(
      <Sparkline data="1,2,3" className="custom-class" />
    );
    expect(container.querySelector('.custom-class')).toBeInTheDocument();
  });
});
