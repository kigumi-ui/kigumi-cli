import React from 'react';
import { render } from '@testing-library/react';
import { ToastItem } from './ToastItem';

describe('ToastItem', () => {
  it('renders without crashing', () => {
    const { container } = render(<ToastItem>Test notification</ToastItem>);
    expect(container.querySelector('wa-toast-item')).toBeInTheDocument();
  });

  it('applies custom className', () => {
    const { container } = render(
      <ToastItem className="custom-class">Test</ToastItem>
    );
    expect(container.querySelector('.custom-class')).toBeInTheDocument();
  });
});
