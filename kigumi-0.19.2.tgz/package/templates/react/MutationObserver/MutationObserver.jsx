import React from 'react';
import clsx from 'clsx';
import './MutationObserver.css';

let loadPromise = null;
function ensureLoaded() {
  return (loadPromise ??=
    import('@awesome.me/webawesome/dist/components/mutation-observer/mutation-observer.js'));
}

export const MutationObserver = React.forwardRef(
  ({ children, className, onMutation, ...props }, ref) => {
    const observerRef = React.useRef(null);

    React.useEffect(() => {
      ensureLoaded();
      const el = observerRef.current;
      if (!el) return;

      const handleMutation = (e) => onMutation?.(e);
      el.addEventListener('wa-mutation', handleMutation);

      return () => {
        el.removeEventListener('wa-mutation', handleMutation);
      };
    }, [onMutation]);

    return (
      <wa-mutation-observer
        ref={(node) => {
          observerRef.current = node;
          if (typeof ref === 'function') ref(node);
          else if (ref) ref.current = node;
        }}
        class={clsx('MutationObserver', className)}
        {...props}
      >
        {children}
      </wa-mutation-observer>
    );
  }
);

MutationObserver.displayName = 'MutationObserver';
