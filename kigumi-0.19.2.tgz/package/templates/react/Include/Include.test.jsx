import { describe, it, expect } from 'vitest';
import { render } from '@testing-library/react';
import React from 'react';
import { Include } from './Include';

describe('Include', () => {
  it('renders without crashing', () => {
    const { container } = render(<Include />);
    expect(container.querySelector('wa-include')).toBeInTheDocument();
  });

  it('applies src prop', () => {
    const { container } = render(<Include src="/content.html" />);
    expect(container.querySelector('wa-include')).toHaveAttribute(
      'src',
      '/content.html'
    );
  });
});
