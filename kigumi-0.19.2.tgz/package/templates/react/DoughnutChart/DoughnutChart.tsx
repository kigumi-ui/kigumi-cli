import {
  forwardRef,
  useRef,
  useCallback,
  useImperativeHandle,
  useEffect,
  type HTMLAttributes,
} from 'react';
import clsx from 'clsx';
import type WaDoughnutChart from '@awesome.me/webawesome/dist/components/doughnut-chart/doughnut-chart.js';
import './DoughnutChart.css';

let loadPromise: Promise<unknown> | null = null;
function ensureLoaded() {
  return (loadPromise ??=
    import('@awesome.me/webawesome/dist/components/doughnut-chart/doughnut-chart.js'));
}

/**
 * Shows proportional segments in a ring shape with an open center for summary content
 *
 * @example
 * ```tsx
 * // Basic usage
 * <DoughnutChart />
 *
 * // With event handlers
 * <DoughnutChart />
 *
 * ```
 */
export interface DoughnutChartProps extends Omit<
  HTMLAttributes<HTMLElement>,
  'dir'
> {
  /** Accessible name announced by assistive technology */
  label?: string;

  /** Extended accessible description for the chart */
  description?: string;

  /** Placement of the dataset legend relative to the chart */
  'legend-position'?: 'top' | 'right' | 'bottom' | 'left' | 'start' | 'end';

  /** Disables entrance and update motion effects */
  'without-animation'?: boolean;

  /** Hides the dataset legend entirely */
  'without-legend'?: boolean;

  /** Prevents hover tooltips from appearing on data points */
  'without-tooltip'?: boolean;
}

export interface DoughnutChartRef {
  /** Reference to the underlying HTML element */
  element: WaDoughnutChart | null;
}

export const DoughnutChart = forwardRef<DoughnutChartRef, DoughnutChartProps>(
  ({ children, className, ...props }, ref) => {
    const doughnutchartRef = useRef<WaDoughnutChart | null>(null);
    const setDoughnutChartRef = useCallback((el: WaDoughnutChart | null) => {
      doughnutchartRef.current = el;
    }, []);

    useImperativeHandle(
      ref,
      () => ({
        get element() {
          return doughnutchartRef.current;
        },
      }),
      []
    );

    useEffect(() => {
      ensureLoaded();
    }, []);

    return (
      <wa-doughnut-chart
        ref={setDoughnutChartRef}
        class={clsx('DoughnutChart', className)}
        {...({ suppressHydrationWarning: true, ...props } as Record<
          string,
          unknown
        >)}
      >
        {children}
      </wa-doughnut-chart>
    );
  }
);

DoughnutChart.displayName = 'DoughnutChart';
