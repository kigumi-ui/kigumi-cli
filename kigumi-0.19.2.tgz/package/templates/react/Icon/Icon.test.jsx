import { describe, it, expect } from 'vitest';
import { render } from '@testing-library/react';
import { Icon } from './Icon';

describe('Icon', () => {
  it('renders without crashing', () => {
    const { container } = render(<Icon name="star" />);
    expect(container.querySelector('wa-icon')).toBeInTheDocument();
  });

  it('applies custom className', () => {
    const { container } = render(<Icon name="star" className="custom-class" />);
    const element = container.querySelector('wa-icon');
    expect(element?.getAttribute('class')).toContain('custom-class');
  });

  it('passes name prop', () => {
    const { container } = render(<Icon name="heart" />);
    const element = container.querySelector('wa-icon');
    expect(element?.getAttribute('name')).toBe('heart');
  });

  it('passes variant and family props', () => {
    const { container } = render(
      <Icon name="star" variant="solid" family="classic" />
    );
    const element = container.querySelector('wa-icon');
    expect(element?.getAttribute('variant')).toBe('solid');
    expect(element?.getAttribute('family')).toBe('classic');
  });

  it('passes label prop for accessibility', () => {
    const { container } = render(<Icon name="star" label="Favorite" />);
    const element = container.querySelector('wa-icon');
    expect(element?.getAttribute('label')).toBe('Favorite');
  });
});
