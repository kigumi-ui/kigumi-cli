import React from 'react';
import clsx from 'clsx';
import './Icon.css';

let loadPromise = null;
function ensureLoaded() {
  return (loadPromise ??=
    import('@awesome.me/webawesome/dist/components/icon/icon.js'));
}

/**
 * Icons are symbols that can be used to represent various options within an application
 *
 * @example
 * ```jsx
 * // Basic usage
 * <Icon name="star" />
 * <Icon name="heart" variant="solid" />
 * <Icon name="github" family="brands" />
 *
 * // With label for accessibility
 * <Icon name="star" label="Favorite" />
 *
 * // Sizing (use CSS or className for sizing)
 * <Icon name="bell" className="icon-large" />
 *
 * // Custom icon
 * <Icon src="/path/to/icon.svg" label="Custom icon" />
 *
 * // With event handlers
 * <Icon
 *   name="image"
 *   onLoad={() => console.log('Icon loaded')}
 *   onError={() => console.log('Icon failed to load')}
 * />
 * ```
 *
 * @typedef {Object} IconProps
 * @property {string} [name] - The name of the icon to draw
 * @property {string} [library] - The name of a registered custom icon library
 * @property {string} [src] - An external URL of an SVG file
 * @property {string} [label] - An alternate description for assistive devices
 * @property {string} [family] - The family of icons (classic, brands, sharp, duotone, sharp-duotone)
 * @property {string} [variant] - The icon's variant (thin, light, regular, solid)
 * @property {boolean} [auto-width] - Sets width to match SVG viewBox
 * @property {boolean} [swap-opacity] - Swaps opacity of duotone icons
 * @property {number} [rotate] - Rotate the icon by this many degrees
 * @property {string} [flip] - Flip: horizontal | vertical | both
 * @property {string} [animation] - Built-in animation name to apply
 * @property {function} [onLoad] - Event fired when icon loads
 * @property {function} [onError] - Event fired when icon fails to load
 */

export const Icon = React.forwardRef(
  ({ className, onLoad, onError, ...props }, ref) => {
    const elementRef = React.useRef(null);

    React.useImperativeHandle(ref, () => elementRef.current, []);

    React.useEffect(() => {
      ensureLoaded();
      const el = elementRef.current;
      if (!el) return;

      const handleLoad = (e) => {
        if (onLoad) onLoad(e);
      };

      const handleError = (e) => {
        if (onError) onError(e);
      };

      el.addEventListener('wa-load', handleLoad);
      el.addEventListener('wa-error', handleError);

      return () => {
        el.removeEventListener('wa-load', handleLoad);
        el.removeEventListener('wa-error', handleError);
      };
    }, [onLoad, onError]);

    return (
      <wa-icon ref={elementRef} class={clsx('Icon', className)} {...props} />
    );
  }
);

Icon.displayName = 'Icon';
