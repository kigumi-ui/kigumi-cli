import React from 'react';
import clsx from 'clsx';
import './AnimatedImage.css';

let loadPromise = null;
function ensureLoaded() {
  return (loadPromise ??=
    import('@awesome.me/webawesome/dist/components/animated-image/animated-image.js'));
}

/**
 * A component for displaying animated GIFs and WEBPs that play and pause on interaction
 *
 * @example
 * ```jsx
 * <AnimatedImage
 *   src="https://example.com/animation.gif"
 *   alt="Animated illustration"
 *   play
 * />
 * ```
 *
 * @typedef {Object} AnimatedImageProps
 * @property {string} src - The path to the image to load
 * @property {string} alt - A description of the image used by assistive devices
 * @property {boolean} [play] - Plays the animation
 * @property {function} [onLoad] - Event fired when the image loads successfully
 * @property {function} [onError] - Event fired when the image fails to load
 * @property {string} [className] - Additional CSS classes
 */

export const AnimatedImage = React.forwardRef(
  ({ className, onLoad, onError, ...props }, ref) => {
    const elementRef = React.useRef(null);

    React.useImperativeHandle(ref, () => elementRef.current, []);

    React.useEffect(() => {
      ensureLoaded();
      const el = elementRef.current;
      if (!el) return;

      const handleLoad = (e) => {
        if (onLoad) onLoad(e);
      };

      const handleError = (e) => {
        if (onError) onError(e);
      };

      el.addEventListener('wa-load', handleLoad);
      el.addEventListener('wa-error', handleError);

      return () => {
        el.removeEventListener('wa-load', handleLoad);
        el.removeEventListener('wa-error', handleError);
      };
    }, [onLoad, onError]);

    return (
      <wa-animated-image
        ref={elementRef}
        class={clsx('AnimatedImage', className)}
        {...props}
      />
    );
  }
);

AnimatedImage.displayName = 'AnimatedImage';
