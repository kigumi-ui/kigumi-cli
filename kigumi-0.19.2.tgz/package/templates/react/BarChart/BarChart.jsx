import React from 'react';
import clsx from 'clsx';
import './BarChart.css';

let loadPromise = null;
function ensureLoaded() {
  return (loadPromise ??=
    import('@awesome.me/webawesome/dist/components/bar-chart/bar-chart.js'));
}

/**
 * Displays categorical data as horizontal or vertical rectangular bars scaled to their values
 *
 * @example
 * ```jsx
 * <BarChart label="Sales by region">
 *   <script type="application/json">{JSON.stringify({
 *     data: {
 *       labels: ['North', 'South', 'East', 'West'],
 *       datasets: [{ label: 'Revenue', data: [42, 38, 55, 29] }]
 *     }
 *   })}</script>
 * </BarChart>
 *
 * // Horizontal orientation
 * <BarChart orientation="horizontal" label="Scores" />
 * ```
 *
 * @typedef {Object} BarChartProps
 * @property {string} [label] - Accessible name announced by assistive technology
 * @property {string} [description] - Extended accessible description for the chart
 * @property {string} [x-label] - Caption displayed beneath the horizontal axis
 * @property {string} [y-label] - Caption displayed beside the vertical axis
 * @property {string} [legend-position] - Placement of the legend: top | right | bottom | left | start | end
 * @property {boolean} [stacked] - Layers multiple datasets on a single axis
 * @property {string} [index-axis] - Base axis for category labels: x | y
 * @property {string} [grid] - Background grid lines: x | y | both | none
 * @property {number} [min] - Floor value for the value axis scale
 * @property {number} [max] - Ceiling value for the value axis scale
 * @property {boolean} [without-animation] - Disables entrance and update motion effects
 * @property {boolean} [without-legend] - Hides the dataset legend entirely
 * @property {boolean} [without-tooltip] - Prevents hover tooltips from appearing on data points
 * @property {string} [orientation] - Controls whether bars grow upward or sideways: vertical | horizontal
 */

export const BarChart = React.forwardRef(
  ({ children, className, ...props }, ref) => {
    const barChartRef = React.useRef(null);

    React.useImperativeHandle(
      ref,
      () => ({
        get element() {
          return barChartRef.current;
        },
      }),
      []
    );

    React.useEffect(() => {
      ensureLoaded();
    }, []);

    return (
      <wa-bar-chart
        ref={barChartRef}
        class={clsx('BarChart', className)}
        {...props}
      >
        {children}
      </wa-bar-chart>
    );
  }
);

BarChart.displayName = 'BarChart';
