import React, { useRef, useImperativeHandle, useEffect } from 'react';
import clsx from 'clsx';
import './TreeItem.css';

let loadPromise = null;
function ensureLoaded() {
  return (loadPromise ??=
    import('@awesome.me/webawesome/dist/components/tree-item/tree-item.js'));
}

export const TreeItem = React.forwardRef(
  (
    {
      children,
      className,
      onCollapse,
      onAfterCollapse,
      onExpand,
      onAfterExpand,
      onLazyChange,
      onLazyLoad,
      ...props
    },
    ref
  ) => {
    const treeItemRef = useRef(null);

    useImperativeHandle(
      ref,
      () => ({
        getChildrenItems: (options) =>
          treeItemRef.current?.getChildrenItems?.(options) ?? [],
        get element() {
          return treeItemRef.current;
        },
      }),
      []
    );

    useEffect(() => {
      ensureLoaded();
      const el = treeItemRef.current;
      if (!el) return;

      const handleCollapse = (e) => onCollapse?.(e);
      const handleAfterCollapse = (e) => onAfterCollapse?.(e);
      const handleExpand = (e) => onExpand?.(e);
      const handleAfterExpand = (e) => onAfterExpand?.(e);
      const handleLazyChange = (e) => onLazyChange?.(e);
      const handleLazyLoad = (e) => onLazyLoad?.(e);

      el.addEventListener('wa-collapse', handleCollapse);
      el.addEventListener('wa-after-collapse', handleAfterCollapse);
      el.addEventListener('wa-expand', handleExpand);
      el.addEventListener('wa-after-expand', handleAfterExpand);
      el.addEventListener('wa-lazy-change', handleLazyChange);
      el.addEventListener('wa-lazy-load', handleLazyLoad);

      return () => {
        el.removeEventListener('wa-collapse', handleCollapse);
        el.removeEventListener('wa-after-collapse', handleAfterCollapse);
        el.removeEventListener('wa-expand', handleExpand);
        el.removeEventListener('wa-after-expand', handleAfterExpand);
        el.removeEventListener('wa-lazy-change', handleLazyChange);
        el.removeEventListener('wa-lazy-load', handleLazyLoad);
      };
    }, [
      onCollapse,
      onAfterCollapse,
      onExpand,
      onAfterExpand,
      onLazyChange,
      onLazyLoad,
    ]);

    return (
      <wa-tree-item
        ref={treeItemRef}
        class={clsx('TreeItem', className)}
        {...props}
      >
        {children}
      </wa-tree-item>
    );
  }
);

TreeItem.displayName = 'TreeItem';
