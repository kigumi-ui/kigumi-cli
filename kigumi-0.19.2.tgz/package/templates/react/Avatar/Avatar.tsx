import {
  forwardRef,
  useRef,
  useCallback,
  useImperativeHandle,
  useEffect,
  type HTMLAttributes,
} from 'react';
import clsx from 'clsx';
import type WaAvatar from '@awesome.me/webawesome/dist/components/avatar/avatar.js';
import './Avatar.css';

let loadPromise: Promise<unknown> | null = null;
function ensureLoaded() {
  return (loadPromise ??=
    import('@awesome.me/webawesome/dist/components/avatar/avatar.js'));
}

/**
 * Avatars are used to represent a person or object
 *
 * @example
 * ```tsx
 * // Basic usage
 * <Avatar />
 *
 * // With event handlers
 * <Avatar
 *   onError={(e) => console.log(e)} />
 *
 * ```
 */
export interface AvatarProps extends Omit<
  HTMLAttributes<HTMLElement>,
  'onError' | 'dir'
> {
  /** The image source to use for the avatar */
  image?: string;

  /** A label to use to describe the avatar to assistive devices */
  label: string;

  /** Initials to use as a fallback when no image is available */
  initials?: string;

  /** Indicates how the browser should load the image */
  loading?: 'eager' | 'lazy';

  /** The shape of the avatar */
  shape?: 'circle' | 'square' | 'rounded';

  /** The image could not be loaded. This may because of an invalid URL, a temporary network condition, or some unknown cause. */
  onError?: (event: CustomEvent) => void;
}

export interface AvatarRef {
  /** Reference to the underlying HTML element */
  element: WaAvatar | null;
}

export const Avatar = forwardRef<AvatarRef, AvatarProps>(
  ({ children, className, onError, ...props }, ref) => {
    const avatarRef = useRef<WaAvatar | null>(null);
    const setAvatarRef = useCallback((el: WaAvatar | null) => {
      avatarRef.current = el;
    }, []);

    useImperativeHandle(
      ref,
      () => ({
        get element() {
          return avatarRef.current;
        },
      }),
      []
    );

    useEffect(() => {
      ensureLoaded();
      const el = avatarRef.current;
      if (!el) return;

      const handleWaError = (e: Event) => {
        if (onError) onError(e as CustomEvent);
      };

      el.addEventListener('wa-error', handleWaError);

      return () => {
        el.removeEventListener('wa-error', handleWaError);
      };
    }, [onError]);

    return (
      <wa-avatar
        ref={setAvatarRef}
        class={clsx('Avatar', className)}
        {...({ suppressHydrationWarning: true, ...props } as Record<
          string,
          unknown
        >)}
      >
        {children}
      </wa-avatar>
    );
  }
);

Avatar.displayName = 'Avatar';
