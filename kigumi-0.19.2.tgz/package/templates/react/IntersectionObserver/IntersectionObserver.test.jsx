import { describe, it, expect } from 'vitest';
import { render } from '@testing-library/react';
import React from 'react';
import { IntersectionObserver } from './IntersectionObserver';

describe('IntersectionObserver', () => {
  it('renders without crashing', () => {
    const { container } = render(
      <IntersectionObserver>
        <div>Content</div>
      </IntersectionObserver>
    );
    expect(
      container.querySelector('wa-intersection-observer')
    ).toBeInTheDocument();
  });
});
