import { describe, it, expect } from 'vitest';
import { render } from '@testing-library/react';
import React from 'react';
import { FormatNumber } from './FormatNumber';

describe('FormatNumber', () => {
  it('renders without crashing', () => {
    const { container } = render(<FormatNumber value={1000} />);
    expect(container.querySelector('wa-format-number')).toBeInTheDocument();
  });

  it('applies value prop', () => {
    const { container } = render(<FormatNumber value={2500} />);
    expect(container.querySelector('wa-format-number')).toHaveAttribute(
      'value',
      '2500'
    );
  });
});
