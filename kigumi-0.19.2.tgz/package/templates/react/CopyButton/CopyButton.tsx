import {
  forwardRef,
  useRef,
  useCallback,
  useImperativeHandle,
  useEffect,
  type HTMLAttributes,
} from 'react';
import clsx from 'clsx';
import type WaCopyButton from '@awesome.me/webawesome/dist/components/copy-button/copy-button.js';
import './CopyButton.css';

let loadPromise: Promise<unknown> | null = null;
function ensureLoaded() {
  return (loadPromise ??=
    import('@awesome.me/webawesome/dist/components/copy-button/copy-button.js'));
}

/**
 * Copies text data to the clipboard when clicked
 *
 * @example
 * ```tsx
 * // Basic usage
 * <CopyButton />
 *
 * // With event handlers
 * <CopyButton
 *   onCopy={(e) => console.log(e)} />
 *
 * ```
 */
export interface CopyButtonProps extends Omit<
  HTMLAttributes<HTMLElement>,
  'onCopy' | 'onError' | 'dir'
> {
  /** The text to copy */
  value?: string;

  /** Element selector to copy text from */
  from?: string;

  /** Disables the button */
  disabled?: boolean;

  /** Tooltip label for copy state */
  'copy-label'?: string;

  /** Tooltip label for success state */
  'success-label'?: string;

  /** Tooltip label for error state */
  'error-label'?: string;

  /** Duration of feedback state in milliseconds */
  'feedback-duration'?: number;

  /** Tooltip position */
  'tooltip-placement'?: 'top' | 'right' | 'bottom' | 'left';

  /** Emitted when the data has been copied. */
  onCopy?: (event: CustomEvent) => void;

  /** Emitted when the data could not be copied. */
  onError?: (event: CustomEvent) => void;
}

export interface CopyButtonRef {
  /** Reference to the underlying HTML element */
  element: WaCopyButton | null;
}

export const CopyButton = forwardRef<CopyButtonRef, CopyButtonProps>(
  ({ children, className, onCopy, onError, ...props }, ref) => {
    const copybuttonRef = useRef<WaCopyButton | null>(null);
    const setCopyButtonRef = useCallback((el: WaCopyButton | null) => {
      copybuttonRef.current = el;
    }, []);

    useImperativeHandle(
      ref,
      () => ({
        get element() {
          return copybuttonRef.current;
        },
      }),
      []
    );

    useEffect(() => {
      ensureLoaded();
      const el = copybuttonRef.current;
      if (!el) return;

      const handleWaCopy = (e: Event) => {
        if (onCopy) onCopy(e as CustomEvent);
      };

      const handleWaError = (e: Event) => {
        if (onError) onError(e as CustomEvent);
      };

      el.addEventListener('wa-copy', handleWaCopy);
      el.addEventListener('wa-error', handleWaError);

      return () => {
        el.removeEventListener('wa-copy', handleWaCopy);
        el.removeEventListener('wa-error', handleWaError);
      };
    }, [onCopy, onError]);

    return (
      <wa-copy-button
        ref={setCopyButtonRef}
        class={clsx('CopyButton', className)}
        {...({ suppressHydrationWarning: true, ...props } as Record<
          string,
          unknown
        >)}
      >
        {children}
      </wa-copy-button>
    );
  }
);

CopyButton.displayName = 'CopyButton';
