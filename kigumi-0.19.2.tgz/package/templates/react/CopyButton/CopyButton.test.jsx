import { describe, it, expect } from 'vitest';
import { render } from '@testing-library/react';
import { CopyButton } from './CopyButton';

describe('CopyButton', () => {
  it('renders without crashing', () => {
    const { container } = render(<CopyButton value="test" />);
    expect(container.querySelector('wa-copy-button')).toBeInTheDocument();
  });

  it('applies custom className', () => {
    const { container } = render(
      <CopyButton value="test" className="custom-class" />
    );
    const element = container.querySelector('wa-copy-button');
    expect(element?.getAttribute('class')).toContain('custom-class');
  });
});
