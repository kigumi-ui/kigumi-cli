import {
  forwardRef,
  useRef,
  useCallback,
  useImperativeHandle,
  useEffect,
  type HTMLAttributes,
} from 'react';
import clsx from 'clsx';
import type WaChart from '@awesome.me/webawesome/dist/components/chart/chart.js';
import './Chart.css';

let loadPromise: Promise<unknown> | null = null;
function ensureLoaded() {
  return (loadPromise ??=
    import('@awesome.me/webawesome/dist/components/chart/chart.js'));
}

/**
 * Renders interactive data visualisations including bars, lines, pies, and more via Chart.js
 *
 * @example
 * ```tsx
 * // Basic usage
 * <Chart />
 *
 * // With event handlers
 * <Chart />
 *
 * ```
 */
export interface ChartProps extends Omit<HTMLAttributes<HTMLElement>, 'dir'> {
  /** Accessible name read by screen readers */
  label?: string;

  /** Supplementary accessible description for the chart */
  description?: string;

  /** Visualisation style to use for the datasets */
  type?:
    | 'bar'
    | 'line'
    | 'pie'
    | 'doughnut'
    | 'polarArea'
    | 'radar'
    | 'scatter'
    | 'bubble';

  /** Text label shown along the horizontal axis */
  'x-label'?: string;

  /** Text label shown along the vertical axis */
  'y-label'?: string;

  /** Where the dataset legend appears around the chart area */
  'legend-position'?: 'top' | 'right' | 'bottom' | 'left' | 'start' | 'end';

  /** Layers multiple datasets on a single axis */
  stacked?: boolean;

  /** Primary axis for categories (swap to create horizontal charts) */
  'index-axis'?: 'x' | 'y';

  /** Controls which background grid lines are visible */
  grid?: 'x' | 'y' | 'both' | 'none';

  /** Lower bound for the value axis scale */
  min?: number;

  /** Upper bound for the value axis scale */
  max?: number;

  /** Turns off entrance and update transitions */
  'without-animation'?: boolean;

  /** Removes the dataset legend from view */
  'without-legend'?: boolean;

  /** Suppresses hover tooltips on data points */
  'without-tooltip'?: boolean;
}

export interface ChartRef {
  /** Reference to the underlying HTML element */
  element: WaChart | null;
}

export const Chart = forwardRef<ChartRef, ChartProps>(
  ({ children, className, ...props }, ref) => {
    const chartRef = useRef<WaChart | null>(null);
    const setChartRef = useCallback((el: WaChart | null) => {
      chartRef.current = el;
    }, []);

    useImperativeHandle(
      ref,
      () => ({
        get element() {
          return chartRef.current;
        },
      }),
      []
    );

    useEffect(() => {
      ensureLoaded();
    }, []);

    return (
      <wa-chart
        ref={setChartRef}
        class={clsx('Chart', className)}
        {...({ suppressHydrationWarning: true, ...props } as Record<
          string,
          unknown
        >)}
      >
        {children}
      </wa-chart>
    );
  }
);

Chart.displayName = 'Chart';
