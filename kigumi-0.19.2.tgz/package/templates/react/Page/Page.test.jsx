import { describe, it, expect } from 'vitest';
import { render } from '@testing-library/react';
import React from 'react';
import { Page } from './Page';

describe('Page', () => {
  it('renders without crashing', () => {
    const { container } = render(<Page />);
    expect(container.querySelector('wa-page')).toBeInTheDocument();
  });

  it('applies custom className', () => {
    const { container } = render(<Page className="custom-class" />);
    const page = container.querySelector('wa-page');
    expect(page?.classList.contains('custom-class')).toBe(true);
  });

  it('renders children content', () => {
    const { getByText } = render(
      <Page>
        <div>Test content</div>
      </Page>
    );
    expect(getByText('Test content')).toBeInTheDocument();
  });

  it('exposes ref methods', () => {
    const ref = React.createRef();
    render(<Page ref={ref} />);

    expect(ref.current).toHaveProperty('hideNavigation');
    expect(ref.current).toHaveProperty('showNavigation');
    expect(ref.current).toHaveProperty('toggleNavigation');
    expect(ref.current).toHaveProperty('visiblePixelsInViewport');
    expect(ref.current).toHaveProperty('element');
  });

  it('accepts navigation-related props', () => {
    const { container } = render(
      <Page
        disableNavigationToggle
        mobileBreakpoint="1024px"
        navigationPlacement="end"
        navOpen={false}
        view="mobile"
      />
    );
    const page = container.querySelector('wa-page');
    expect(page).toBeInTheDocument();
  });
});
