import React from 'react';
import clsx from 'clsx';
import './DropdownItem.css';

let loadPromise = null;
function ensureLoaded() {
  return (loadPromise ??=
    import('@awesome.me/webawesome/dist/components/dropdown-item/dropdown-item.js'));
}

/**
 * @typedef {Object} DropdownItemRef
 * @property {() => void} openSubmenu
 * @property {() => void} closeSubmenu
 * @property {HTMLElement | null} element
 */

export const DropdownItem = React.forwardRef(
  ({ children, className, ...props }, ref) => {
    const itemRef = React.useRef(null);

    React.useImperativeHandle(
      ref,
      () => ({
        openSubmenu: () => itemRef.current?.openSubmenu?.(),
        closeSubmenu: () => itemRef.current?.closeSubmenu?.(),
        get element() {
          return itemRef.current;
        },
      }),
      []
    );

    React.useEffect(() => {
      ensureLoaded();
    }, []);

    return (
      <wa-dropdown-item
        ref={itemRef}
        class={clsx('DropdownItem', className)}
        {...props}
      >
        {children}
      </wa-dropdown-item>
    );
  }
);

DropdownItem.displayName = 'DropdownItem';
