import React from 'react';
import clsx from 'clsx';
import './ButtonGroup.css';

let loadPromise = null;
function ensureLoaded() {
  return (loadPromise ??=
    import('@awesome.me/webawesome/dist/components/button-group/button-group.js'));
}

/**
 * Groups related buttons into organized sections, supporting both horizontal and vertical layouts
 *
 * @example
 * ```jsx
 * // Basic horizontal button group
 * <ButtonGroup>
 *   <Button>Left</Button>
 *   <Button>Middle</Button>
 *   <Button>Right</Button>
 * </ButtonGroup>
 *
 * // Vertical orientation
 * <ButtonGroup orientation="vertical">
 *   <Button>Top</Button>
 *   <Button>Middle</Button>
 *   <Button>Bottom</Button>
 * </ButtonGroup>
 *
 * // With accessibility label
 * <ButtonGroup label="Text alignment">
 *   <Button><Icon name="align-left" /></Button>
 *   <Button><Icon name="align-center" /></Button>
 *   <Button><Icon name="align-right" /></Button>
 * </ButtonGroup>
 * ```
 *
 * @typedef {Object} ButtonGroupProps
 * @property {string} [label] - A label to use for the button group
 * @property {'horizontal' | 'vertical'} [orientation] - Controls the button group's layout direction
 */

export const ButtonGroup = React.forwardRef(
  ({ children, className, ...props }, ref) => {
    React.useEffect(() => {
      ensureLoaded();
    }, []);

    return (
      <wa-button-group
        ref={ref}
        class={clsx('ButtonGroup', className)}
        {...props}
      >
        {children}
      </wa-button-group>
    );
  }
);

ButtonGroup.displayName = 'ButtonGroup';
