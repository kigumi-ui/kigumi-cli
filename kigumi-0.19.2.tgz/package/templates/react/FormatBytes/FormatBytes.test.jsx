import { describe, it, expect } from 'vitest';
import { render } from '@testing-library/react';
import React from 'react';
import { FormatBytes } from './FormatBytes';

describe('FormatBytes', () => {
  it('renders without crashing', () => {
    const { container } = render(<FormatBytes value={1024} />);
    expect(container.querySelector('wa-format-bytes')).toBeInTheDocument();
  });

  it('applies value prop', () => {
    const { container } = render(<FormatBytes value={2048} />);
    expect(container.querySelector('wa-format-bytes')).toHaveAttribute(
      'value',
      '2048'
    );
  });
});
