import React from 'react';
import clsx from 'clsx';
import './Button.css';

let loadPromise = null;
function ensureLoaded() {
  return (loadPromise ??=
    import('@awesome.me/webawesome/dist/components/button/button.js'));
}

/**
 * Buttons represent actions that are available to the user
 *
 * @example
 * ```jsx
 * <Button variant="brand">Click me</Button>
 * <Button appearance="outlined" size="large">Large Button</Button>
 * <Button loading>Loading...</Button>
 * <Button type="submit" form="myForm">Submit</Button>
 *
 * // With event handlers
 * <Button onBlur={() => console.log('Lost focus')}>
 *   Button
 * </Button>
 *
 * // With ref methods
 * const buttonRef = React.useRef(null);
 * <button onClick={() => buttonRef.current?.focus()}>Focus Button</button>
 * <Button ref={buttonRef}>Focusable</Button>
 * ```
 *
 * @typedef {Object} ButtonProps
 * @property {string} [variant] - Semantic variant: neutral | brand | success | warning | danger
 * @property {string} [appearance] - Visual appearance: accent | filled | outlined | filled-outlined | plain
 * @property {string} [size] - Button size: small | medium | large
 * @property {boolean} [pill] - Rounded edges
 * @property {boolean} [disabled] - Disables button
 * @property {boolean} [loading] - Shows loading indicator
 * @property {boolean} [with-caret] - Adds dropdown caret
 * @property {string} [href] - Makes button work like link
 * @property {string} [target] - Link target: _blank | _self | _parent | _top
 * @property {string} [download] - Download filename
 * @property {string} [rel] - Link relationship
 * @property {string} [type] - Button type for form submission: button | submit | reset
 * @property {string} [name] - Name for form submission
 * @property {string} [value] - Value for form submission
 * @property {string} [formaction] - Override form action
 * @property {string} [formenctype] - Override form enctype
 * @property {string} [formmethod] - Override form method
 * @property {boolean} [formnovalidate] - Bypass form validation
 * @property {string} [formtarget] - Override form target
 * @property {function} [onBlur] - Event fired when button loses focus
 * @property {function} [onFocus] - Event fired when button gains focus
 */

export const Button = React.forwardRef(
  ({ children, className, onBlur, onFocus, ...props }, ref) => {
    const buttonRef = React.useRef(null);

    React.useImperativeHandle(
      ref,
      () => ({
        focus: () => {
          if (
            buttonRef.current &&
            typeof buttonRef.current.focus === 'function'
          ) {
            buttonRef.current.focus();
          }
        },
        blur: () => {
          if (
            buttonRef.current &&
            typeof buttonRef.current.blur === 'function'
          ) {
            buttonRef.current.blur();
          }
        },
        click: () => {
          if (
            buttonRef.current &&
            typeof buttonRef.current.click === 'function'
          ) {
            buttonRef.current.click();
          }
        },
        get element() {
          return buttonRef.current;
        },
      }),
      []
    );

    React.useEffect(() => {
      ensureLoaded();
      const el = buttonRef.current;
      if (!el) return;

      const handleBlur = (e) => {
        if (onBlur) onBlur(e);
      };

      const handleFocus = (e) => {
        if (onFocus) onFocus(e);
      };

      el.addEventListener('blur', handleBlur);
      el.addEventListener('focus', handleFocus);

      return () => {
        el.removeEventListener('blur', handleBlur);
        el.removeEventListener('focus', handleFocus);
      };
    }, [onBlur, onFocus]);

    return (
      <wa-button ref={buttonRef} class={clsx('Button', className)} {...props}>
        {children}
      </wa-button>
    );
  }
);

Button.displayName = 'Button';
