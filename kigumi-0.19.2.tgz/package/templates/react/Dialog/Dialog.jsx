import React from 'react';
import { createPortal } from 'react-dom';
import clsx from 'clsx';
import './Dialog.css';

let loadPromise = null;
function ensureLoaded() {
  return (loadPromise ??=
    import('@awesome.me/webawesome/dist/components/dialog/dialog.js'));
}

/**
 * Dialogs display important prompts and information
 *
 * @example
 * // Using open prop (recommended)
 * const [open, setOpen] = React.useState(false);
 * <Dialog open={open} label="Dialog Title" onHide={() => setOpen(false)}>
 *   <p>Dialog content</p>
 *   <Button slot="footer" variant="brand" onClick={() => setOpen(false)}>
 *     Close
 *   </Button>
 * </Dialog>
 *
 * // Using ref methods (alternative)
 * const dialogRef = React.useRef(null);
 * <Dialog ref={dialogRef} label="Dialog Title">
 *   <p>Dialog content</p>
 * </Dialog>
 * dialogRef.current?.show();
 *
 * @param {Object} props
 * @param {boolean} [props.open] - Indicates whether or not the dialog is open
 * @param {string} props.label - The dialog's label as displayed in the header
 * @param {boolean} [props['without-header']] - Disables the header and removes the default close button
 * @param {boolean} [props['light-dismiss']] - When enabled, the dialog will be closed when the user clicks outside of it
 * @param {function} [props.onShow] - Event fired when the dialog is shown
 * @param {function} [props.onAfterShow] - Event fired after the dialog is shown
 * @param {function} [props.onHide] - Event fired when the dialog is about to hide
 * @param {function} [props.onAfterHide] - Event fired after the dialog is hidden
 * @param {string} [props.className] - Additional CSS classes
 * @param {React.ReactNode} [props.children] - Dialog content
 * @param {React.Ref} ref - Ref with methods: show(), hide(), requestClose()
 */
export const Dialog = React.forwardRef(
  (
    {
      children,
      className,
      open,
      onShow,
      onAfterShow,
      onHide,
      onAfterHide,
      ...props
    },
    ref
  ) => {
    const dialogRef = React.useRef(null);

    React.useImperativeHandle(
      ref,
      () => ({
        show: () => dialogRef.current?.show?.(),
        hide: () => dialogRef.current?.requestClose?.(),
        requestClose: () => dialogRef.current?.requestClose?.(),
        get element() {
          return dialogRef.current;
        },
      }),
      []
    );

    // Sync open prop with dialog element
    React.useEffect(() => {
      ensureLoaded();
      const el = dialogRef.current;
      if (!el || open === undefined) return;

      const isOpen = el.open ?? false;
      if (open && !isOpen) {
        el.show?.();
      } else if (!open && isOpen) {
        el.requestClose?.();
      }
    }, [open]);

    // Setup event listeners
    React.useEffect(() => {
      const el = dialogRef.current;
      if (!el) return;

      const handleShow = (e) => onShow?.(e);
      const handleAfterShow = (e) => onAfterShow?.(e);
      const handleHide = (e) => onHide?.(e);
      const handleAfterHide = (e) => onAfterHide?.(e);

      el.addEventListener('wa-show', handleShow);
      el.addEventListener('wa-after-show', handleAfterShow);
      el.addEventListener('wa-hide', handleHide);
      el.addEventListener('wa-after-hide', handleAfterHide);

      return () => {
        el.removeEventListener('wa-show', handleShow);
        el.removeEventListener('wa-after-show', handleAfterShow);
        el.removeEventListener('wa-hide', handleHide);
        el.removeEventListener('wa-after-hide', handleAfterHide);
      };
    }, [onShow, onAfterShow, onHide, onAfterHide]);

    return createPortal(
      <wa-dialog ref={dialogRef} class={clsx('Dialog', className)} {...props}>
        {children}
      </wa-dialog>,
      document.body
    );
  }
);

Dialog.displayName = 'Dialog';
