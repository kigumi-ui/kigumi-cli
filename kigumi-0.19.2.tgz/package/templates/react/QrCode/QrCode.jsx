import React from 'react';
import clsx from 'clsx';
import './QrCode.css';

let loadPromise = null;
function ensureLoaded() {
  return (loadPromise ??=
    import('@awesome.me/webawesome/dist/components/qr-code/qr-code.js'));
}

export const QrCode = React.forwardRef(({ className, ...props }, ref) => {
  React.useEffect(() => {
    ensureLoaded();
  }, []);

  return <wa-qr-code ref={ref} class={clsx('QrCode', className)} {...props} />;
});

QrCode.displayName = 'QrCode';
